# 📡 CloudWatch Agent Setup on Amazon Linux 2023

This mini-project sets up a **production-ready Amazon CloudWatch Agent** configuration to monitor key system metrics and application logs on an **Amazon Linux 2023 EC2 instance**.

---

## ✅ What It Monitors

- **System Metrics**:
  - CPU: Idle, system, and user usage
  - Memory: Percentage used
  - Disk: Root (`/`) usage
- **Application Logs**:
  - Apache error log at `/var/log/httpd/error_log`

---

## 🧪 Environment Tested

- **OS**: Amazon Linux 2023  
- **AMI ID**: `ami-08a6efd148b1f7504`

---

## 📁 Project Structure

```
cloudwatch-agent-al2023/
├── config/
│   └── config.json        # CloudWatch Agent configuration
└── scripts/
    └── start-agent.sh     # Script to apply and start the agent
```

---

## 🚀 How to Deploy

### 1. Upload the Config File

```bash
sudo mkdir -p /opt/aws/amazon-cloudwatch-agent/bin/
sudo cp config/config.json /opt/aws/amazon-cloudwatch-agent/bin/
```

### 2. Start the CloudWatch Agent

```bash
sudo bash scripts/start-agent.sh
```

### 3. Check Agent Status

```bash
systemctl status amazon-cloudwatch-agent
```

---

## 📊 Log Group & Output

- **CloudWatch Log Group**:  
  `/ec2/log/httpd-error` (for Apache error log)

- **Metrics & Logs Verified**:
  - CPU, memory, and disk metrics appear in CloudWatch
  - Apache error logs are ingested into the defined log group

---

## 🧾 Notes

- Ensure that IAM Role attached to the instance has:
  - `AmazonSSMManagedInstanceCore`
  - `CloudWatchAgentServerPolicy`
- The EC2 instance must have outbound access to AWS (via IGW or NAT)

---

## 🚀 Ready to Monitor!
