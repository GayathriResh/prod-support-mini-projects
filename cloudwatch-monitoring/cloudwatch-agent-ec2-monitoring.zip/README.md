# 📊 CloudWatch Agent Setup for Amazon Linux 2023 (EC2 Monitoring)

This project provides a **production-ready configuration** to monitor an EC2 instance running **Amazon Linux 2023** using the **Amazon CloudWatch Agent**.

---

## ✅ What It Monitors

- **CPU**: Idle, system, and user usage
- **Memory**: Percentage used
- **Disk**: Root (`/`) usage percentage
- **Application Logs**:  
  Apache Error Log – `/var/log/httpd/error_log`

---

## 📁 Project Structure

```
cloudwatch-agent-ec2-monitoring/
├── config.json       # CloudWatch Agent configuration
└── README.md         # Documentation
```

---

## 🛠️ Troubleshooting: Session Manager & CloudWatch Agent Setup

### Step 1: Launch & Prepare EC2 Instance

- EC2 instance with **Amazon Linux 2023** in a **public subnet**
- IAM Role attached with the following policies:
  - `AmazonSSMManagedInstanceCore`
  - `CloudWatchAgentServerPolicy`

---

### ❌ Issue Faced

> *SSM Agent is not online. The agent was unable to connect to the Systems Manager endpoint.*

---

### 🔍 Investigation

- ✅ Verified `amazon-ssm-agent` was running
- ✅ Confirmed instance had a public IP and IGW route

---

### 🛡️ Root Cause

The **Security Group lacked an egress rule for HTTPS (TCP 443)**.  
SSM Agent requires outbound internet access to connect to AWS endpoints.

---

### ✅ Fix

Added the following **Security Group Egress Rule**:

- **Type**: HTTPS  
- **Port**: 443  
- **Destination**: `0.0.0.0/0`

---

### 🎉 Result

- ✅ **Session Manager** connection successful
- ✅ **CloudWatch Agent** started pushing metrics and logs

---

## 🧾 Notes

- Tested on AMI: `ami-08a6efd148b1f7504`
- Platform: **Amazon Linux 2023**
- Metrics and logs visible in CloudWatch Console

---

## 🚀 Happy Monitoring!
